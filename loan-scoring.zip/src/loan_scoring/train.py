"""
Train the loan approval model with a proper held-out evaluation.

Critical difference from the original notebook: there, the final model
(cells 59-62) was retrained on SMOTE-resampled *full* data with no
test set at all -- so there was no way to know its real-world accuracy.
Here, the test split happens first and is never touched by SMOTE or
any fitted transform; everything is fit on the training fold only.
"""
from __future__ import annotations

import argparse
import json
import logging
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import joblib
import pandas as pd
from sklearn.metrics import classification_report, f1_score
from sklearn.model_selection import train_test_split

from .pipeline import DEFAULT_MODEL_PARAMS, build_training_pipeline, to_inference_pipeline
from .schema import ALL_FEATURES, ID_COLUMN, TARGET

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)


def _git_commit_hash() -> str | None:
    try:
        return (
            subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], stderr=subprocess.DEVNULL)
            .decode()
            .strip()
        )
    except Exception:
        return None


def train(data_path: Path, artifacts_dir: Path, version: str, test_size: float = 0.2) -> Path:
    logger.info("Loading training data from %s", data_path)
    raw = pd.read_csv(data_path)

    raw = raw.copy()
    if "Dependents" in raw.columns:
        raw["Dependents"] = raw["Dependents"].astype(str)
    raw[TARGET] = raw[TARGET].map({"Y": 1, "N": 0}).fillna(raw[TARGET])

    X = raw[ALL_FEATURES]
    y = raw[TARGET].astype(int)

    x_train, x_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=y
    )
    logger.info("Train rows: %d | Test rows: %d (held out, untouched by SMOTE)", len(x_train), len(x_test))

    pipeline = build_training_pipeline(DEFAULT_MODEL_PARAMS)
    pipeline.fit(x_train, y_train)

    y_pred = pipeline.predict(x_test)
    test_f1 = f1_score(y_test, y_pred)
    report = classification_report(y_test, y_pred, output_dict=True)
    logger.info("Held-out test F1: %.4f", test_f1)

    inference_pipeline = to_inference_pipeline(pipeline)

    artifacts_dir.mkdir(parents=True, exist_ok=True)
    stem = f"model_v{version}"
    model_path = artifacts_dir / f"{stem}.joblib"
    metadata_path = artifacts_dir / f"{stem}.metadata.json"

    joblib.dump(inference_pipeline, model_path)

    metadata = {
        "version": version,
        "trained_at_utc": datetime.now(timezone.utc).isoformat(),
        "git_commit": _git_commit_hash(),
        "training_rows": len(x_train),
        "test_rows": len(x_test),
        "test_f1": test_f1,
        "classification_report": report,
        "model_params": DEFAULT_MODEL_PARAMS,
        "feature_columns": ALL_FEATURES,
        "data_source": str(data_path),
    }
    metadata_path.write_text(json.dumps(metadata, indent=2))

    logger.info("Saved model artifact: %s", model_path)
    logger.info("Saved metadata: %s", metadata_path)
    return model_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the loan approval scoring model")
    parser.add_argument("--data", type=Path, default=Path("data/loan_data_set.csv"))
    parser.add_argument("--artifacts-dir", type=Path, default=Path("artifacts"))
    parser.add_argument("--version", type=str, required=True, help="e.g. 1.0.0")
    parser.add_argument("--test-size", type=float, default=0.2)
    args = parser.parse_args()

    if not args.data.exists():
        raise FileNotFoundError(
            f"Training data not found at {args.data}. This repo does not ship "
            f"the loan_data_set.csv (it's not in the original GitHub repo either) "
            f"-- place your training data there or pass --data."
        )

    train(args.data, args.artifacts_dir, args.version, args.test_size)


if __name__ == "__main__":
    main()
