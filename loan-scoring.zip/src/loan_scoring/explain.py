"""
Per-decision SHAP explainability for batch scoring output.

In lending, a denial (or approval) often needs a defensible, specific reason
attached to it for compliance review -- "the model said so" isn't sufficient.
This module attaches the top contributing features to each prediction.

Uses shap.TreeExplainer directly against the fitted GradientBoostingClassifier
inside the pipeline (not the wrapped pipeline itself), operating on the
already-preprocessed feature matrix produced by the pipeline's preprocessing
step. This keeps explanations in terms of the actual encoded/scaled values the
classifier sees, which is correct for the model but means raw category labels
(e.g. "Urban") are reported as their encoded numeric form -- documented at the
call site below.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import shap
from sklearn.pipeline import Pipeline

from .schema import CATEGORICAL_FEATURES, NUMERIC_FEATURES

FEATURE_ORDER = NUMERIC_FEATURES + CATEGORICAL_FEATURES


class BatchExplainer:
    """
    Wraps a fitted inference pipeline (preprocess -> classify) to produce
    per-row top-N feature attributions. Built once per scoring run and
    reused across chunks -- constructing a TreeExplainer has fixed overhead
    that shouldn't be repeated per chunk.
    """

    def __init__(self, pipeline: Pipeline, top_n: int = 3):
        if "preprocess" not in pipeline.named_steps or "classify" not in pipeline.named_steps:
            raise ValueError("Expected a pipeline with 'preprocess' and 'classify' steps")
        self.preprocessor = pipeline.named_steps["preprocess"]
        self.classifier = pipeline.named_steps["classify"]
        self.top_n = top_n
        self.explainer = shap.TreeExplainer(self.classifier)

    def explain(self, feature_df: pd.DataFrame) -> pd.DataFrame:
        """
        Returns a DataFrame (same row order/index as feature_df) with:
          - shap_top_reasons: human-readable "Feature (+/-value)" string, signed
            toward the predicted class
          - shap_base_value: the model's baseline (expected) log-odds before
            any feature contributions
        """
        transformed = self.preprocessor.transform(feature_df)
        if hasattr(transformed, "toarray"):
            transformed = transformed.toarray()
        transformed = np.asarray(transformed)

        raw_shap = self.explainer.shap_values(transformed)

        # shap.TreeExplainer on a binary GradientBoostingClassifier returns a
        # single (n_samples, n_features) array of contributions to the
        # positive class log-odds; normalize a couple of known alternate
        # shapes defensively so this doesn't break across shap versions.
        if isinstance(raw_shap, list):
            raw_shap = raw_shap[-1]
        if raw_shap.ndim == 3:
            raw_shap = raw_shap[:, :, -1]

        base_value = self.explainer.expected_value
        if isinstance(base_value, (list, np.ndarray)):
            base_value = np.ravel(base_value)[-1]

        reasons = []
        for row_shap in raw_shap:
            ranked_idx = np.argsort(-np.abs(row_shap))[: self.top_n]
            parts = [f"{FEATURE_ORDER[i]} ({row_shap[i]:+.3f})" for i in ranked_idx]
            reasons.append("; ".join(parts))

        return pd.DataFrame(
            {
                "shap_top_reasons": reasons,
                "shap_base_value": [float(base_value)] * len(feature_df),
            },
            index=feature_df.index,
        )
