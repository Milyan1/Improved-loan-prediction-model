"""
Batch scoring entrypoint, designed to be invoked on a schedule
(cron, Airflow, Prefect, GitHub Actions -- whatever your client already runs).

Usage:
    python -m loan_scoring.score \
        --input data/applications_2026_06_30.csv \
        --output results/scored_2026_06_30.csv \
        --model artifacts/model_v1.0.0.joblib \
        --chunk-size 50000

Design choices that matter at scale:
  - Reads input in chunks, so a multi-GB file doesn't need to fit in memory.
  - Bad rows are quarantined to a sidecar file instead of crashing the run --
    one malformed application shouldn't block scoring the other 49,999.
  - Every run emits a structured JSON summary (row counts, error counts,
    prediction distribution, timing) suitable for log aggregation and
    drift monitoring across runs over time.
"""
from __future__ import annotations

import argparse
import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path

import joblib
import pandas as pd

from .explain import BatchExplainer
from .schema import ID_COLUMN, validate_schema

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)


def score_file(
    input_path: Path,
    output_path: Path,
    model_path: Path,
    chunk_size: int = 50_000,
    quarantine_path: Path | None = None,
    explain: bool = False,
) -> dict:
    run_started = time.time()
    model = joblib.load(model_path)
    model_version = model_path.stem

    explainer = BatchExplainer(model, top_n=3) if explain else None

    quarantine_path = quarantine_path or output_path.with_suffix(".quarantine.csv")

    total_rows = 0
    total_scored = 0
    total_quarantined = 0
    all_errors: list[str] = []
    prediction_counts = {0: 0, 1: 0}

    output_path.parent.mkdir(parents=True, exist_ok=True)
    first_chunk = True
    first_quarantine_chunk = True

    reader = pd.read_csv(input_path, chunksize=chunk_size)
    for chunk_idx, chunk in enumerate(reader):
        total_rows += len(chunk)
        result = validate_schema(chunk, require_id=True)

        if not result.quarantined_rows.empty:
            total_quarantined += len(result.quarantined_rows)
            all_errors.extend(result.errors)
            result.quarantined_rows.to_csv(
                quarantine_path, mode="w" if first_quarantine_chunk else "a",
                header=first_quarantine_chunk, index=False,
            )
            first_quarantine_chunk = False

        if result.valid_rows.empty:
            continue

        feature_df = result.valid_rows.drop(columns=[ID_COLUMN])
        predictions = model.predict(feature_df)
        probabilities = model.predict_proba(feature_df)[:, 1]

        out = result.valid_rows[[ID_COLUMN]].copy()
        out["prediction"] = predictions
        out["prediction_label"] = pd.Series(predictions).map({1: "Approved", 0: "Not Approved"})
        out["approval_probability"] = probabilities
        out["model_version"] = model_version
        out["scored_at_utc"] = datetime.now(timezone.utc).isoformat()

        if explainer is not None:
            reasons = explainer.explain(feature_df)
            out["shap_top_reasons"] = reasons["shap_top_reasons"].values
            out["shap_base_value"] = reasons["shap_base_value"].values

        out.to_csv(output_path, mode="w" if first_chunk else "a", header=first_chunk, index=False)
        first_chunk = False

        total_scored += len(out)
        for val, count in pd.Series(predictions).value_counts().items():
            prediction_counts[int(val)] = prediction_counts.get(int(val), 0) + int(count)

        logger.info("Chunk %d: %d rows scored, %d quarantined", chunk_idx, len(out), len(result.quarantined_rows))

    run_summary = {
        "input_path": str(input_path),
        "output_path": str(output_path),
        "model_version": model_version,
        "run_completed_utc": datetime.now(timezone.utc).isoformat(),
        "duration_seconds": round(time.time() - run_started, 2),
        "total_rows_read": total_rows,
        "total_rows_scored": total_scored,
        "total_rows_quarantined": total_quarantined,
        "quarantine_rate": round(total_quarantined / total_rows, 4) if total_rows else 0.0,
        "prediction_distribution": {
            "approved": prediction_counts.get(1, 0),
            "not_approved": prediction_counts.get(0, 0),
        },
        "quarantine_errors_sample": all_errors[:20],
    }

    logger.info("Run summary: %s", json.dumps(run_summary, indent=2))
    return run_summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Batch-score loan applications")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--chunk-size", type=int, default=50_000)
    parser.add_argument("--run-log", type=Path, default=None, help="Optional path to append JSON run summaries for monitoring")
    parser.add_argument("--explain", action="store_true", help="Attach SHAP top-reason feature attributions to each scored row")
    args = parser.parse_args()

    summary = score_file(args.input, args.output, args.model, args.chunk_size, explain=args.explain)

    if args.run_log:
        args.run_log.parent.mkdir(parents=True, exist_ok=True)
        with open(args.run_log, "a") as f:
            f.write(json.dumps(summary) + "\n")


if __name__ == "__main__":
    main()
