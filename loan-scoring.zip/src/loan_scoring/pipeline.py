"""
Preprocessing + model as a single, self-contained pipeline.

The original notebook applied a sqrt transform and a StandardScaler to
a DataFrame in-place, then saved only the raw classifier with joblib --
the scaler and transform were never persisted. This module fixes that
by building one sklearn Pipeline object that owns every transform step.
Saving this pipeline saves everything; loading it restores everything.
SMOTE lives inside the *training-only* pipeline (imblearn.Pipeline), so
it only ever resamples the training fold, never validation or scoring data.
"""
from __future__ import annotations

import numpy as np
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OrdinalEncoder, StandardScaler

from .schema import CATEGORICAL_FEATURES, NUMERIC_FEATURES

# Default hyperparameters carried over from the original notebook's final model.
DEFAULT_MODEL_PARAMS = dict(
    n_estimators=270,
    min_samples_split=5,
    min_samples_leaf=5,
    max_features="sqrt",
    max_depth=5,
    random_state=42,
)


def _safe_sqrt(X: np.ndarray) -> np.ndarray:
    """Sqrt transform that won't throw on negative/zero edge cases from bad input."""
    return np.sqrt(np.clip(X, a_min=0, a_max=None))


def build_preprocessor() -> ColumnTransformer:
    numeric_pipeline = Pipeline(
        steps=[
            ("impute", SimpleImputer(strategy="mean")),
            ("sqrt", FunctionTransformer(_safe_sqrt, feature_names_out="one-to-one")),
            ("scale", StandardScaler()),
        ]
    )

    categorical_pipeline = Pipeline(
        steps=[
            ("impute", SimpleImputer(strategy="most_frequent")),
            (
                "encode",
                # unknown_value=-1 means a category never seen at training time
                # gets a sentinel value instead of crashing the whole batch --
                # paired with schema.validate_schema(), which flags and
                # quarantines those rows *before* they reach this point.
                OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1),
            ),
        ]
    )

    return ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
        ]
    )


def build_training_pipeline(model_params: dict | None = None) -> ImbPipeline:
    """
    Full pipeline used only during training: preprocess -> SMOTE -> classify.
    SMOTE is an imblearn step, so it's a no-op at inference time and never
    touches validation/test/production data -- it only resamples whatever
    training fold is passed to .fit().
    """
    params = model_params or DEFAULT_MODEL_PARAMS
    return ImbPipeline(
        steps=[
            ("preprocess", build_preprocessor()),
            ("smote", SMOTE(random_state=42)),
            ("classify", GradientBoostingClassifier(**params)),
        ]
    )


def to_inference_pipeline(trained_pipeline: ImbPipeline) -> Pipeline:
    """
    Strip the SMOTE step out of a fitted training pipeline before saving
    it for inference. SMOTE is a resampling step with no transform()
    method meant for unseen data -- it must never run at scoring time.
    """
    steps = [(name, step) for name, step in trained_pipeline.steps if name != "smote"]
    return Pipeline(steps=steps)
