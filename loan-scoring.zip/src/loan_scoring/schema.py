"""
Explicit data contract for the loan approval model.

This is the single source of truth for what a valid input row looks like.
Both training (train.py) and batch scoring (score.py) import from here,
so the contract can never drift between the two -- which was the root
cause of the bug in the original notebook (model trained on transformed
features, inference fed raw ones).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

# Columns the model consumes as features.
NUMERIC_FEATURES = [
    "Applicant_Income",
    "Coapplicant_Income",
    "Loan_Amount",
    "Loan_Amount_Term",
]

CATEGORICAL_FEATURES = [
    "Gender",
    "Married",
    "Dependents",
    "Education",
    "Self_Employed",
    "Credit_History",
    "Property_Area",
]

ALL_FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES

TARGET = "Loan_Status"

# An identifier column carried through scoring output but never used as a feature.
ID_COLUMN = "Loan_ID"

# Known valid categories at training time. Used by the encoder's
# handle_unknown logic and by validate_schema for an early, readable error.
EXPECTED_CATEGORIES = {
    "Gender": {"Male", "Female"},
    "Married": {"Yes", "No"},
    "Dependents": {"0", "1", "2", "3+"},
    "Education": {"Graduate", "Not Graduate"},
    "Self_Employed": {"Yes", "No"},
    "Credit_History": {0.0, 1.0},
    "Property_Area": {"Urban", "Semiurban", "Rural"},
}


@dataclass
class SchemaValidationResult:
    valid_rows: pd.DataFrame
    quarantined_rows: pd.DataFrame
    errors: list[str] = field(default_factory=list)


def validate_schema(df: pd.DataFrame, require_id: bool = True) -> SchemaValidationResult:
    """
    Validate a batch of input rows against the data contract.

    Rows that are missing required columns entirely raise immediately --
    that's a structural problem with the whole file, not a single bad row.
    Rows with bad/unknown values in individual columns are quarantined
    (split out) rather than crashing the whole batch run, and the reasons
    are recorded so they can be logged and investigated.
    """
    required_cols = ALL_FEATURES + ([ID_COLUMN] if require_id else [])
    missing_cols = [c for c in required_cols if c not in df.columns]
    if missing_cols:
        raise ValueError(
            f"Input file is missing required columns: {missing_cols}. "
            f"Expected columns: {required_cols}"
        )

    bad_row_mask = pd.Series(False, index=df.index)
    errors: list[str] = []

    # Flag missing values in any required feature.
    na_mask = df[ALL_FEATURES].isna().any(axis=1)
    if na_mask.any():
        errors.append(f"{na_mask.sum()} row(s) had missing values in required features")
    bad_row_mask |= na_mask

    # Flag categorical values outside the known training-time categories.
    for col, allowed in EXPECTED_CATEGORIES.items():
        unknown_mask = ~df[col].isin(allowed) & df[col].notna()
        if unknown_mask.any():
            bad_values = df.loc[unknown_mask, col].unique().tolist()
            errors.append(f"{unknown_mask.sum()} row(s) had unexpected values in '{col}': {bad_values}")
        bad_row_mask |= unknown_mask

    # Flag non-numeric / negative values in numeric columns.
    for col in NUMERIC_FEATURES:
        numeric_col = pd.to_numeric(df[col], errors="coerce")
        invalid_mask = numeric_col.isna() | (numeric_col < 0)
        if invalid_mask.any():
            errors.append(f"{invalid_mask.sum()} row(s) had invalid/negative values in '{col}'")
        bad_row_mask |= invalid_mask

    return SchemaValidationResult(
        valid_rows=df.loc[~bad_row_mask].copy(),
        quarantined_rows=df.loc[bad_row_mask].copy(),
        errors=errors,
    )
