import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from loan_scoring.explain import BatchExplainer
from loan_scoring.pipeline import build_training_pipeline, to_inference_pipeline
from loan_scoring.schema import ALL_FEATURES, validate_schema


def _toy_dataframe(n=60, seed=0):
    rng = np.random.default_rng(seed)
    df = pd.DataFrame(
        {
            "Loan_ID": [f"LP{i:04d}" for i in range(n)],
            "Gender": rng.choice(["Male", "Female"], n),
            "Married": rng.choice(["Yes", "No"], n),
            "Dependents": rng.choice(["0", "1", "2", "3+"], n),
            "Education": rng.choice(["Graduate", "Not Graduate"], n),
            "Self_Employed": rng.choice(["Yes", "No"], n),
            "Credit_History": rng.choice([0.0, 1.0], n),
            "Property_Area": rng.choice(["Urban", "Semiurban", "Rural"], n),
            "Applicant_Income": rng.uniform(1500, 9000, n),
            "Coapplicant_Income": rng.uniform(0, 4000, n),
            "Loan_Amount": rng.uniform(50, 500, n),
            "Loan_Amount_Term": rng.choice([360.0, 180.0, 120.0], n),
            "Loan_Status": rng.choice([0, 1], n),
        }
    )
    return df


def test_pipeline_is_self_contained_after_save_load(tmp_path):
    """The artifact produced must include preprocessing, not just the classifier --
    this is the exact bug that broke the original notebook's inference path."""
    import joblib

    df = _toy_dataframe()
    X, y = df[ALL_FEATURES], df["Loan_Status"]

    pipeline = build_training_pipeline()
    pipeline.fit(X, y)
    inference_pipeline = to_inference_pipeline(pipeline)

    path = tmp_path / "model.joblib"
    joblib.dump(inference_pipeline, path)
    loaded = joblib.load(path)

    # Raw, untransformed features go in; predictions come out with no manual
    # preprocessing step required by the caller.
    preds = loaded.predict(X)
    assert len(preds) == len(X)
    assert set(preds).issubset({0, 1})


def test_smote_step_is_stripped_for_inference():
    df = _toy_dataframe()
    X, y = df[ALL_FEATURES], df["Loan_Status"]

    pipeline = build_training_pipeline()
    pipeline.fit(X, y)
    inference_pipeline = to_inference_pipeline(pipeline)

    step_names = [name for name, _ in inference_pipeline.steps]
    assert "smote" not in step_names


def test_validate_schema_flags_unknown_category():
    df = _toy_dataframe(n=5)
    df.loc[0, "Property_Area"] = "Moon Base"  # not a known category

    result = validate_schema(df)
    assert len(result.quarantined_rows) == 1
    assert len(result.valid_rows) == 4
    assert any("Property_Area" in e for e in result.errors)


def test_validate_schema_flags_missing_required_column():
    df = _toy_dataframe(n=5).drop(columns=["Credit_History"])
    with pytest.raises(ValueError, match="missing required columns"):
        validate_schema(df)


def test_validate_schema_flags_negative_income():
    df = _toy_dataframe(n=5)
    df.loc[0, "Applicant_Income"] = -100
    result = validate_schema(df)
    assert len(result.quarantined_rows) == 1


def test_inference_pipeline_handles_unseen_category_without_crashing():
    """Production data will eventually contain a category the model never
    saw at training time. The encoder must degrade gracefully, not throw."""
    df = _toy_dataframe()
    X, y = df[ALL_FEATURES], df["Loan_Status"]
    pipeline = build_training_pipeline()
    pipeline.fit(X, y)
    inference_pipeline = to_inference_pipeline(pipeline)

    new_row = X.iloc[[0]].copy()
    new_row["Property_Area"] = "Unseen_Category_XYZ"
    # Should not raise -- OrdinalEncoder(handle_unknown="use_encoded_value") absorbs it.
    preds = inference_pipeline.predict(new_row)
    assert len(preds) == 1


def test_shap_explainer_produces_top_reasons_for_each_row():
    df = _toy_dataframe()
    X, y = df[ALL_FEATURES], df["Loan_Status"]
    pipeline = build_training_pipeline()
    pipeline.fit(X, y)
    inference_pipeline = to_inference_pipeline(pipeline)

    explainer = BatchExplainer(inference_pipeline, top_n=3)
    explanations = explainer.explain(X)

    assert len(explanations) == len(X)
    assert {"shap_top_reasons", "shap_base_value"} <= set(explanations.columns)
    # Each reason string should list exactly top_n "Feature (+/-value)" entries.
    sample = explanations.iloc[0]["shap_top_reasons"]
    assert sample.count(";") == 2  # 3 entries joined by "; " -> 2 separators

