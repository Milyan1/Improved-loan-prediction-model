# Loan Approval — Batch Scoring System

A productionized rebuild of the original `Loan Approval.ipynb` notebook, restructured
for scheduled batch scoring of loan applications at scale.

## What changed from the original notebook

| Issue in the notebook | Fix here |
|---|---|
| `joblib.dump` saved only the classifier — the `StandardScaler` and sqrt transform were never persisted | Preprocessing and model are one `sklearn.Pipeline` object; saving/loading the artifact saves/loads everything |
| Inference cell fed raw user input directly into a model trained on sqrt-transformed features | The transform lives inside the pipeline now — there is no separate manual step to forget |
| SMOTE applied to the full dataset before any train/test split | SMOTE runs inside the training-only pipeline, fit exclusively on the training fold; the held-out test set is never resampled or otherwise touched |
| Final shipped model had no held-out evaluation at all | `train.py` always reports test-set F1 and a full classification report, saved alongside the model artifact |
| Hardcoded category mappings silently mishandled unseen values | `schema.py` defines the data contract explicitly; unseen categories are quarantined before scoring, and the encoder degrades gracefully if one slips through |
| Inference was a blocking `input()` loop in a notebook | `score.py` is a CLI batch entrypoint, chunked for large files, schedulable via cron/Airflow/anything |
| No versioning | Every trained model gets a version string, a timestamp, and a metadata JSON sidecar with its metrics |

## Project layout

```
.github/workflows/tests.yml  # CI: runs pytest on every push/PR
src/loan_scoring/
  schema.py    # data contract + validation/quarantine logic
  pipeline.py  # preprocessing + model as one sklearn Pipeline
  train.py     # training with held-out evaluation, versioned artifacts
  score.py     # batch scoring entrypoint
  explain.py   # SHAP per-decision feature attribution
tests/
  test_pipeline.py
Dockerfile
requirements.txt
```

## Setup

```bash
pip install -r requirements.txt
```

## Training

```bash
PYTHONPATH=src python -m loan_scoring.train \
  --data data/loan_data_set.csv \
  --version 1.0.0
```

Produces `artifacts/model_v1.0.0.joblib` and `artifacts/model_v1.0.0.metadata.json`
(training date, git commit, row counts, held-out F1, full classification report).

**Note:** `loan_data_set.csv` is not included — it also wasn't present in the original
GitHub repo. Supply your own training data matching the schema in `schema.py`.

## Batch scoring

```bash
PYTHONPATH=src python -m loan_scoring.score \
  --input data/applications.csv \
  --output results/scored.csv \
  --model artifacts/model_v1.0.0.joblib \
  --chunk-size 50000 \
  --run-log results/run_log.jsonl \
  --explain
```

- Reads in chunks, so file size isn't memory-bound.
- Rows that fail schema validation (missing fields, unknown categories, invalid
  numeric values) are written to `results/scored.quarantine.csv` instead of
  crashing the run.
- Each run appends a JSON summary line to `--run-log`: row counts, quarantine
  rate, prediction distribution, duration — feed this into whatever monitoring
  you already run to watch for input drift over time.
- `--explain` attaches `shap_top_reasons` and `shap_base_value` columns to
  every scored row — see below.

## Explainability

Passing `--explain` attaches a SHAP-based attribution to every row in the
output: a `shap_top_reasons` column listing the three features that moved
that specific decision most (with signed contribution toward approval), and
`shap_base_value`, the model's baseline before any feature effects. This is
built for exactly the situation a compliance reviewer or an applicant
disputing a denial runs into — "why was *this* application decided this way,"
not just an aggregate feature-importance chart for the model as a whole.

The explainer (`explain.py`) is built once per scoring run and reused across
chunks, since constructing a `shap.TreeExplainer` has fixed overhead that
shouldn't be paid per chunk. Attributions are computed on the same encoded/
scaled feature matrix the classifier actually sees, so a value like
`Property_Area (+1.389)` refers to the encoded representation of that
category, not the raw label — worth keeping in mind if these get surfaced
directly to a non-technical reviewer.

## Scheduling

The `Dockerfile` builds a self-contained scorer image:

```bash
docker build -t loan-scoring .
docker run -v $(pwd)/data:/app/data -v $(pwd)/results:/app/results loan-scoring \
  --input data/applications.csv --output results/scored.csv --model artifacts/model_v1.0.0.joblib --explain
```

This runs identically under cron, Airflow's `DockerOperator`, a GitHub Actions
scheduled workflow, or any other orchestrator a client already has in place.

## Tests & CI

```bash
PYTHONPATH=src pytest tests/ -v
```

`.github/workflows/tests.yml` runs the same suite on every push and pull
request against `main`, on Python 3.11 and 3.12.

## Suggested next steps

- **Drift monitoring**: the `run_log.jsonl` prediction-distribution field is a
  starting point — compare distributions run over run and alert on large shifts.
- **Human-readable SHAP labels**: map encoded categorical values back to their
  original labels (e.g. `Property_Area=Urban` instead of the encoded integer)
  if `shap_top_reasons` will be shown to non-technical reviewers.
